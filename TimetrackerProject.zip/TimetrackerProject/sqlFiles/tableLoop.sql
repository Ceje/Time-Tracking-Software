use db;
DELIMITER $$              
CREATE Procedure tablePullLoop() 
  BEGIN
    DECLARE command VARCHAR(300); 
    DECLARE v_uID VARCHAR(20);
    DECLARE v_done INT DEFAULT 0; 
    DECLARE cur CURSOR FOR SELECT table_name FROM information_schema.tables WHERE table_schema='temp' AND TABLE_TYPE NOT LIKE 'VIEW';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = 1;
    OPEN cur;
      REPEAT
          set v_done =0;
          FETCH cur INTO v_uID;  
          IF NOT v_done THEN
            set @c = CONCAT('INSERT IGNORE INTO db.entry (employeeID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop) SELECT employeeID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop FROM temp.',v_uID);
            PREPARE command FROM @c;
            EXECUTE command;
            
            set @dv = CONCAT('DROP VIEW temp.', v_uID,'view');
            PREPARE dropView from @dv;
            EXECUTE dropView;
            
            set @d = CONCAT('DROP TABLE temp.', v_uID);
            PREPARE dropTable FROM @d;
            EXECUTE dropTable;
          END IF;
          
      UNTIL v_done END REPEAT;
    CLOSE cur; 
  END $$

DELIMITER ;

CREATE EVENT tablePull ON SCHEDULE AT '2014-11-09 23:59:59'+ INTERVAL 7 DAY DO CALL tablePullLoop();

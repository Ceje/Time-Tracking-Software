<?php
  $user = $pass = "";
  
  if($_SERVER["REQUEST_METHOD"]=="POST"){ #only accept posts
    $user = test_input($_POST["Username"]);  #sanitize inputs
    $pass = test_input($_POST["Pass"]);
    $conn = new mysqli("localhost",$user,$pass,"db");
    if($conn->connect_error){                                #attempt connecting with given paramiters, if failed output error
      header( "refresh:2.5;url=login.html" );
      echo "Database connection failed: Please check your Username and Password";
      die();
    }
    else{
      session_start();
      $_SESSION["User"]=$user; #if succes start a session and store variables.
      $_SESSION["Pass"]=$pass;
      $_SESSION["mod"]=False;
      $_SESSION["landing"]='entry';
      ini_set("session.cookie_lifetime","3600");
      $result = mysqli_query($conn, "SELECT * FROM c.test"); #test if mod status
      
      if($result){
        $_SESSION["mod"]=True; #if mod mark as such
	$_SESSION["landing"]='search';
      }
      $result = mysqli_query($conn, "SELECT * FROM employee WHERE employeeID='$user'"); # retrieve employee info
      $row = mysqli_fetch_array($result);
      $_SESSION['fName']=$row['firstName']; #store first/last name
      $_SESSION['lName']=$row['lastName'];
      $conn->close(); # close DB connection
      header('Location: main.php'); #pass to Main landing
      die();   #terminate this page
    }    
  }
   
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
  }
?>

<!DOCTYPE html>
<html>
<head>
  <?php session_start();
    date_default_timezone_set('America/Chicago');
    $sDate = (new DateTime('-1 month'))->format('Y-m-d\TH:i');
    $eDate = (new DateTime())->format('Y-m-d\TH:i');
    $fName=$_SESSION['fName'];
    $lName=$_SESSION['lName'];
    $user=$_SESSION['User'];
    $_SESSION['landing']='search'; 
  ?>
</head>
<body>
  <nav>
    <form id='saveSearch' action='download.php' method='POST'> <!-- hidden form to pass to save-->
    </form>
      <form id='fullSearch' ><!-- form to pass to search functions, all elements besides submit are also tied to the save form-->
        <?php if($_SESSION['mod']==1){echo "First Name:";}?>
	<input form='saveSearch' <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='fname' value='<?php echo $fName; ?>'> 
        <?php if($_SESSION['mod']==1){echo "Last Name:";}?> 
	<input form='saveSearch' <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='lname' value='<?php echo $lName; ?>'>
        <?php if($_SESSION['mod']==1){echo "User Name:";}?> 
	<input form='saveSearch' <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='uname' id='suname' value='<?php if($_SESSION['mod']!=1){ echo $user;}?>'><br>
        Date Start: <input type='datetime-local' name='sdate' form='saveSearch' value='<?php echo $sDate; ?>' ><br>
        Date End: <input type='datetime-local' name='edate' value='<?php echo $eDate; ?>' form='saveSearch'><br>
        Company: <input type='text' id='compSearch' name='comp' list='compList' form='saveSearch'>
		<datalist id='compList'></dataList>
        Project: <input type='text' id='projSearch' name='proj' list='projList' form='saveSearch'>
		<datalist id='projList'></datalist><br>
        Role: <input type='text' id='roleSearch' name='role' list='roleList' form='saveSearch'>
		<datalist id='roleList'></datalist>
        Activity: <input type='text' id='actSearch' name='act' list='actList' form='saveSearch'>
		<datalist id='actList'></datalist><br>
        Issue: <input type='text' name='bug' form='saveSearch'><br>
        Notes: <br><textarea name='notes' maxlenght='256' rows="4" cols="50" form='saveSearch'></textarea><br>
        <input type='hidden' id='stable' name='tableName' value='db.entry' form='saveSearch'> 
        <input id='fullSeachSubmit' type='submit' value='Search'>
      </form>
  </nav>
  <section id='results'>
    <h3> Scheduled to submit </h3>
      <div id='tempDBResults'><!-- temp results are displayed here -->
      </div><br>
      <button id='saveTemp' type='button' onClick="save('Temp')">Save Temp Results </button><!-- saves temp results for current search-->
    <h3> Search Result </h3>
      <div id='coreDBResults'><!-- core DB results are put here -->
      </div>   <br>
      <button id='saveMain' type='button' onClick="save('Main')">Save Submitted Results</button> <!-- saves core results for current search-->
  </section>
</body>

<!DOCTYPE html>
<html>
<head>
<?php 
  session_start();
  $_SESSION['landing']='newUser';
?>
</head>
<body>
  User Select:<select id="userDBResults"><!-- user list fills into here --></select>
    <!--Delete button -->
    <br>
  <!-- confirm delete, (hidden)-->
  <!-- form to create new user -->
  <form id="userForm" method="post">
    <div id='userInfo'>
      First Name: <input name='fName'> Last Name: <input name='lName'><br>
      User Name: <input name='uname' required ><br> 
      Password: <input type='password' class='pass' name='pass1'><br>
      Password Confirm: <input type='password' class='pass' name='pass2'><br> 
      <p style='display:none;' id='passFix'>The Password Fields Must Match</p>                                                                     
      <button type='button' id='showpass'> Display Password.</button>
      <br>
      <input type='checkbox' name='modbox' val='True'>Moderator Clearance<br>
    </div>
    <input type='submit' value='Submit'><button type='button' id='removeUser'>Delete User</button>
    <div style='display:none;' id='confirmation'>
      <input type='password' id='removePassword'>
      <button type='button' id='confirmDelete'>Confirm Deletion</button>
    </div>
  </form>
</body>

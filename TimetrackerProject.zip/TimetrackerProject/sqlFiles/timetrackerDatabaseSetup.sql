create database db;  -- create core database
use db;
create database temp; -- create temp database
create database c;  -- create modcheck database
create user admin@localhost identified by 'clubchucker1130';  -- create dummy user 1 super admin
grant all on *.* to admin@localhost;
CREATE TABLE Roles (roleName VARCHAR(100) NOT NULL, activity VARCHAR(100) NOT NULL, PRIMARY KEY(roleName, activity));    -- create tables for the core database
CREATE TABLE Employee (employeeID varchar(20) NOT NULL, firstName VARCHAR(20), lastName VARCHAR(20),PRIMARY KEY (employeeID));
CREATE TABLE Project (projectName VARCHAR(100) NOT NULL, roleName VARCHAR(100) REFERENCES Roles(roleName), PRIMARY KEY (projectName,roleName));
CREATE TABLE Company (companyName VARCHAR(100) NOT NULL, projectName VARCHAR(100) NOT NULL REFERENCES Project(projectName), PRIMARY KEY (companyName, projectName));
CREATE TABLE Entry (entryID INT UNSIGNED NOT NULL AUTO_INCREMENT, employeeID varchar(20) NOT NULL REFERENCES Employee(employeeID),companyName VARCHAR(100) NOT NULL REFERENCES Company (companyName),projectName VARCHAR(100) NOT NULL REFERENCES Project (projectName),roleName VARCHAR(100) REFERENCES Roles(roleName), activity VARCHAR(100) REFERENCES Roles(activity), issue VARCHAR(256), notes VARCHAR (256), timeStart DATETIME NOT NULL, timeStop DATETIME NOT NULL, PRIMARY KEY (entryID));
CREATE VIEW entryView AS select firstName, lastName, employeeID, entryID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop, TIMESTAMPDIFF(SECOND, timeStart, timeStop)/3600 AS timeSpent FROM db.entry NATURAL JOIN db.employee;
use c;
create table test(results BOOLEAN); -- create table to query for admin checks
insert into test VALUES (True);
use db;

DELIMITER $$                 -- create procedure to pull temp tables to db.entry
CREATE Procedure tablePullLoop() 
  BEGIN
    DECLARE command VARCHAR(300); 
    DECLARE uID VARCHAR(20);
    DECLARE done INT DEFAULT 0; 
    DECLARE cur CURSOR FOR SELECT table_name FROM information_schema.tables WHERE table_schema='temp' AND TABLE_TYPE NOT LIKE 'VIEW';
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN cur;
      REPEAT
       
          FETCH cur INTO uID;  
          IF done THEN
            set @c = CONCAT('INSERT INTO db.entry (employeeID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop) SELECT employeeID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop FROM temp.', uID);
            PREPARE command FROM @c;
            EXECUTE command;
            
            set @dv = CONCAT('DROP VIEW temp.', uID,'view');
            PREPARE dropView from @dv;
            EXECUTE dropView;
            
            set @d = CONCAT('DROP TABLE temp.', uID);
            PREPARE dropTable FROM @d;
            EXECUTE dropTable;
          END IF;
          
      UNTIL done END REPEAT;
    CLOSE cur; 
  END $$

CREATE Procedure newUser(uName varchar(20), pWord varchar(20),  fName varchar(20), lName varchar(20), mods boolean) 
  BEGIN
    set @nUser = CONCAT('CREATE USER ', uName, '@localhost IDENTIFIED BY ''', pWord,'''');
    PREPARE newUser from @nUser;
    EXECUTE newUser;   
    set @perms = CONCAT('GRANT ALL on temp.* to ',uName,'@localhost');
    PREPARE perm1 from @perms;
    EXECUTE perm1;
    set @perms = CONCAT('GRANT CREATE VIEW on db.* to ',uName,'@localhost');
    PREPARE perm6 from @perms;
    Execute perm6;
    IF mods THEN
      set @perms = CONCAT('GRANT ALL on db.* to ', uName,'@localhost');
      PREPARE perm2 from @perms;
      EXECUTE perm2;
      set @perms = CONCAT('GRANT ALL on c.* to ', uName,'@localhost');
      PREPARE perm3 from @perms;
      EXECUTE perm3;
      set @perms = CONCAT('GRANT SELECT on *.* to ', uName,'@localhost');
      PREPARE perm5 from @perms;
      EXECUTE perm5;
    ELSE
      set @perms = CONCAT('GRANT SELECT on db.* to ', uName, '@localhost');
      PREPARE perm4 from @perms;
      EXECUTE perm4;
    END IF;
    set @empEntry = CONCAT('INSERT INTO db.employee VALUES (''',uName,''', ''',fName,''', ''',lName,''')');
    PREPARE newEmployee from @empEntry;
    EXECUTE newEmployee;
  END $$

DELIMITER ;

CREATE EVENT tablePull ON SCHEDULE AT '2014-11-09 23:59:59'+ INTERVAL 7 DAY DO CALL tablePullLoop(); -- set up interval to pull tables every sunday night

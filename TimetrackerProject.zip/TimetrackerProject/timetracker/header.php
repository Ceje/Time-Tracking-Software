<!DOCTYPE html>	
<html>
<head>
  <?php session_start();    
    date_default_timezone_set('America/Chicago');
    $sDay=new DateTime('-1 month');
    $sDate=$sDay->format('Y-m-d\TH:i');
    $eDay=new DateTime();
    $eDate=$eDay->format('Y-m-d\TH:i'); 
    $landing=$_SESSION["landing"];
  ?>
</head>
<body>
<nav>
<div>
<div id="links"><ul>
  <li><a id="searchNav" href="search">Search</a></li>
  <li><a id="entryNav" href="entry">Enter Time Tracker</a></li><!-- link section, Entry | Users | Comp/Roles --> 
      <?php
        if($_SESSION["mod"]==1){   #<!-- only show user and company edits if moderator -->
         echo "<li><a id='nUserNav' href='User'>New User</a></li> "; 
         echo "<li><a id='compRoleEdit' href='roleedit'>Company & Role Edit</a></li> ";
        }
      ?>
  <li><a id="profileNav" href="profile">Change Password</a></li>
  <li><a href="logout.php">Logout</a></li>
</ul>
</div>
<select id='pageSelect' >
    <option value='Search' <?php if($landing=='search'){echo 'selected';}?>>Search</option>
    <option value='Enter Timetracker'<?php if($landing=='entry'){echo 'selected';}?>>Enter Timetracker</option>
    <?php if($_SESSION['mod']==1){
      echo "<option value='Edit Users'";
      if($landing=='newUser'){echo "selected";}
      echo ">Edit Users</option> <option value='Edit Companies and Roles'";
      if($landing=='newComp'){echo "selected";}
      echo ">Edit Companies and Roles</option>";
    }?>
    <option value='Edit Profile' <?php if($landing=='cPass'){echo 'selected';}?> >Change Password</option>
  </select>  
  <hr>       
<h1><?php echo "Welcome ".$_SESSION['fName'].' '.$_SESSION['lName']; ?>!<br> <!-- welcome section --></h1>
<table id="welcome">
<!-- quicksearch form-->
  <form action="search.php" method="post" id='quickSearch'>
   <tr><td> <?php if($_SESSION['mod']==1){echo "User Name:";}?> <input  <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='uname' value='<?php if($_SESSION['mod']!=1){ echo $_SESSION['User'];}?>' id='QSuName'></td>
   <td> <?php if($_SESSION['mod']==1){echo "First Name:";}?> <input <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='fname' value='<?php echo $_SESSION['fName'];?>' id='QSlName'></td>
   <td> <?php if($_SESSION['mod']==1){echo "Last Name:";}?> <input  <?php if($_SESSION['mod']!=1){echo "type='hidden'";} ?> name='lname' value='<?php echo $_SESSION['lName'];?>' id='QAuName'></td></tr>
   <tr><td> Date Start: <input type='datetime-local' name='sdate' value='<?php echo $sDate; ?>' id='QSsDate'></td>
   <td> Date End: <input type='datetime-local' name='edate' value='<?php echo $eDate; ?>' id='QSeDate'></td>
   <td> <input id='submit' type='submit' value='Quick Search'></td></tr>
  </form></table>
</nav>
</body>
</html>

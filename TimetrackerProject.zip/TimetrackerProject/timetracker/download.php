<?php
  #connect to session
  session_start();
  #create file
  $output=tmpfile();
  #get file info
  $metaDatas= stream_get_meta_data($output);
  #get file name
  $outputName=$metaDatas['uri'];
  #create string
  $str='';
  #create MYSQL Query
  $query="Select * FROM ".varFill($_POST['tableName'])." WHERE employeeID LIKE '%".varFill($_POST['uname'])."%' AND firstName LIKE '%".varFill($_POST['fname'])."%' AND lastName LIKE '%".varFill($_POST['lname'])."%' AND companyName LIKE '%".varFill($_POST['comp'])."%' AND projectName LIKE '%".varFill($_POST['proj'])."%' AND roleName LIKE '%".varFill($_POST['role'])."%' AND activity LIKE '%".varFill($_POST['act'])."%' AND issue LIKE '%".varFill($_POST['bug'])."%' AND notes LIKE '%".varFill($_POST['notes'])."%' AND (timeStart < '".dateTrim(varFill($_POST['edate']))."' AND timeStop > '".dateTrim(varFill($_POST['sdate']))."' ) ORDER BY timeStart DESC";
  #implement query
  $conn = new mysqli("localhost",$_SESSION['User'],$_SESSION['Pass'],"db");
  $data = mysqli_query($conn, $query);
  echo $conn->error;
  $conn->close();
  #if query successful format and append data
  if($data){
    if(mysqli_num_rows($data)>0){
      $str.="<?xml version='1.0' encoding='UTF-8' standalone='yes'?>\n";
      $str.="<data-set xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'>\n";
      while($row = mysqli_fetch_array($data)) {
        $str.="<record>\n";
        foreach($row as $column => $value){
          if(!is_int($column)){
            $str.="<$column>$value</$column>\n";
          }
        }
        $str.="</record>\n";
      }
      $str.="</data-set>";
    }  
    else{
      echo("NO RESULTS");
    }
  }
  #bad query, output for review
  else{
    echo("\nREQUEST FAILED: ".$query);
  }
  #write output to file
  fwrite($output,$str);  
  
  	
  #file download 
	if(ini_get('zlib.output_compression')) { ini_set('zlib.output_compression', 'Off');	}
   // required for IE
	// get the file mime type using the file extension
	switch(strtolower(substr(strrchr($outputName, '.'), 1))) {
		case 'pdf': $mime = 'application/pdf'; break;
		case 'zip': $mime = 'application/zip'; break;
		case 'jpeg':
		case 'jpg': $mime = 'image/jpg'; break;
		default: $mime = 'application/force-download';
	}
	header('Pragma: public'); 	// required
	header('Expires: 0');		// no cache
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($outputName)).' GMT');
	header('Cache-Control: private',false);
	header('Content-Type: '.$mime);
	header('Content-Disposition: attachment; filename="data.xml"');
	header('Content-Transfer-Encoding: binary');
	header('Content-Length: '.filesize($outputName));	// provide file size
	header('Connection: close');
	readfile($outputName);		// push it out
  fclose($output);
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    if($data!='<' && $data!='>'){
      $data = htmlspecialchars($data);
    }
    return $data;
  }
  
  #sanitizers and formatting
  function varFill($data){
    if(isset($data)&&(!($data==''))){return test_input($data);}
    else {return null;}
  }
  function dateTrim($date){  
    $str=substr($date,0,10).' '.substr($date, 11,strlen($date)).":00";
    return $str; 
  }
?>
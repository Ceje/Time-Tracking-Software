//main page functions

//load starting page
$(document).ready(function(){
  loadHeader();
  loadFooter();
  window.onbeforeunload = function(){
    return 'Navigating away from this page may require you to login again. Are you sure you want to leave?';
  }
  
});

//load timetracker entry page
function loadEntry(){      
  //get html frame
  getting=$.get('entry.php');
  getting.done(function(data){
    $('#content').empty().append(data);
    
    //rig change events onto the drop lists
    $(document).off('change.entryComp').on('change.entryComp', '#entryComp', function(){
      listGrab('companyName','projectName','company','#entryComp','#entryProj','select');
    });
    $(document).off('change.entryProj').on('change.entryProj', '#entryProj', function(){
       listGrab('projectName','roleName','project','#entryProj','#entryRole','select');
    });
    $(document).off('change.entryRole').on('change.entryRole', '#entryRole', function(){
      listGrab('roleName','activity','roles','#entryRole', '#entryAct','select');
    });
  
    //grab company dropdown list
    listGrab('','companyName','company','','#entryComp','select');
    //assign form and fill the temp table
    form=$('#entryForm');
    user=form.find("input[name='uname']").val();
    entryCheck([['1','=','1',''],['ORDER BY', 'timeStart','DESC','']], user);
  
    //rig refresh to button click
    $(document).off('click.tempRefresh').on('click.tempRefresh', '#tempRefresh', function(){
      form=$('#entryForm');
      user=form.find("input[name='uname']").val();
      entryCheck([['1','=','1',''],['ORDER BY', 'timeStart','DESC','']], user);
    });
    //rig submit event handling for entering a time tracker item
    $(document).off('submit.entryForm').on('submit.entryForm', '#entryForm', function(event){
      event.preventDefault();
      var $form=$(this);
      timeStart=form.find("input[name='sdate']").val()+':00.000';
      timeEnd=form.find("input[name='edate']").val()+':00.000';  
      timeStart=Date.parse(timeStart);
      timeEnd=Date.parse(timeEnd);
      if($('#entryComp').val()!='null'&&$('#entryProj').val()!='null'&&!(timeStart>timeEnd))
      {
        submit($form, 'insert');
      }
    });                        
  });
}


// load user edit page
function loadNewUser(){
  //get html frame
  getting=$.get('newUser.php');
  getting.done(function(data){
    $('#content').empty().append(data);
    
    
    
    //rig submit event for new user creation
    $(document).off('submit.userForm').on('submit.userForm', '#userForm', function(){
      event.preventDefault();
      var $form=$(this);
      if($('#userDBResults').val()=='New User'){
        createUser($form);
      }
      else{
        updateUser($form);
      }
    });
    
    //pull user list
    listGrab('','user','mysql.user','','#userDBResults','New User');
    
    //rig actions for remove user button
    $(document).off('click.removeUser').on('click.removeUser', '#removeUser', function(){
      if($('#userDBResults').val()!='New User'){
        $('#confirmation').fadeIn();
      }
    });
    //rig remove user to deactivate if the user changes
    $(document).off('change.userDBResults').on('change.userDBResults','#userDBResults',function(){
      loadUser();
    });
    //rig true deletion to the confirm button
    $(document).off('click.confirmDelete').on('click.confirmDelete','#confirmDelete',function(){
      deleteUser()
      $('#confirmation').fadeOut();
    });
    $(document).off('mousedown.showpass').on('mousedown.showpass','#showpass', function(){
       document.getElementsByClassName('pass')[0].type='text';
    });
    $(document).off('mouseup.showpass').on('mouseup.showpass','#showpass', function(){
       document.getElementsByClassName('pass')[0].type='password';
    });
  });
}

//load search page
function loadSearch(){
  //get html frame
  getting=$.get('search.php');
  getting.done(function(data){
    $('#content').empty().append(data);
    $(document).off('change.compSearch').on('change.compSearch', '#compSearch', function(){
      listGrab('companyName','projectName','company','#compSearch','#projList','');
    });
    $(document).off('change.projSearch').on('change.projSearch', '#projSearch', function(){
       listGrab('projectName','roleName','project','#projSearch','#roleList','');
    });
    $(document).off('change.roleSearch').on('change.roleSearch', '#roleSearch', function(){
      listGrab('roleName','activity','roles','#roleSearch', '#actList','');
    });
    listGrab('','companyName','company','','#compList','');
    //rig search event
    $(document).off('submit.fullSearch').on('submit.fullSearch','#fullSearch',function(event){
      event.preventDefault();
      var $form = $(this);
      search($form);
    });
    
    //set up a default search on load, in this case the search in the quicksearch section
    quickSearch($('#quickSearch'));
  });
}

//load header section for the main page
function loadHeader(){
  //load html frame
  getting=$.get('header.php');
  getting.done(function(data){
    $('#header').empty().append(data).ready(function(){
      pageLoad();
    });
  
    //rig search page loading to link
    $(document).off('click.searchNav').on('click.searchNav','#searchNav',function(){
      event.preventDefault();
      $('#pageSelect').val('Search').change();  
    });
    $(document).off('click.entryNav').on('click.entryNav','#entryNav',function(){
      event.preventDefault();
      $('#pageSelect').val('Enter Timetracker').change();  
     	
    }); 
    //rig search page load and search to the quick search button
    $(document).off('submit.quickSearch').on('submit.quickSearch','#quickSearch',function( event ) {
      event.preventDefault();
      $('#pageSelect').val('Search').change();  
      
    });
    $(document).off('change.pageSelect').on('change.pageSelect','#pageSelect',function(){
      pageLoad();
    }); 
    $(document).off('click.nUserNav').on('click.nUserNav','#nUserNav',function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Users').change();  
    });
    $(document).off('click.profileNav').on('click.profileNave','#profileNav', function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Profile').change();  
    });
    //rig event for loading the new/edit company page
    $(document).off('click.compRoleEdit').on('click.compRoleEdit','#compRoleEdit',function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Companies and Roles').change();  
    });
    //rig event for changing drop down lists
    $(document).off('change.editComp').on('change.editComp', '#editComp', function(){
      listGrab('companyName','projectName','company','#editComp','#editProj','');
    });
    $(document).off('change.editProj').on('change.editProj', '#editProj', function(){
       listGrab('projectName','roleName','project','#editProj','#editRole','');
    });
    $(document).off('change.editRole').on('change.editRole', '#editRole', function(){
      listGrab('roleName','activity','roles','#editRole', '#editAct','');
    });
  });
}
function pageLoad(){
  loadingPage=$('#pageSelect').val();
  
  pageLoader(loadingPage);
}
function pageLoader(loadingPage){
  $('a').fadeIn();
  switch(loadingPage){
    case 'Search':
      loadSearch();
      $('#searchNav').fadeOut();
      break;
    case 'Enter Timetracker':
      loadEntry();
      $('#entryNav').fadeOut();
      break;
    case 'Edit Users':
      loadNewUser();
      $('#nUserNav').fadeOut();
      break;
    case 'Edit Companies and Roles':
      loadCompRoleEdit();
      $('#compRoleEdit').fadeOut();
      break;
    case 'Edit Profile':
      loadProfileEdit();
      $('#profileNav').fadeOut();
      break;
  }
}

//load footer section for the main page
function loadFooter(){
  //load html frame
  getting=$.get('footer.php');
  getting.done(function(data){
    $('#footer').empty().append(data);
    
    //rig event for loading the new/edit user page
    $(document).off('click.nUserNav').on('click.nUserNav','#nUserNav',function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Users').change();  
    });
    $(document).off('click.profileNav').on('click.profileNave','#profileNav', function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Profile').change();  
    });
    //rig event for loading the new/edit company page
    $(document).off('click.compRoleEdit').on('click.compRoleEdit','#compRoleEdit',function(){
      event.preventDefault();
      $('#pageSelect').val('Edit Companies and Roles').change();  
    });
    //rig event for changing drop down lists
    $(document).off('change.editComp').on('change.editComp', '#editComp', function(){
      listGrab('companyName','projectName','company','#editComp','#editProj','');
    });
    $(document).off('change.editProj').on('change.editProj', '#editProj', function(){
       listGrab('projectName','roleName','project','#editProj','#editRole','');
    });
    $(document).off('change.editRole').on('change.editRole', '#editRole', function(){
      listGrab('roleName','activity','roles','#editRole', '#editAct','');
    });
  });
  
}

//load company & role editing page
function loadCompRoleEdit(){
  //get html frame
  getting=$.get('newComp.php');
  getting.done(function(data){
    $('#content').empty().append(data);
    //rig event for changing the selection boxes
    $(document).off('change.compSel').on('change.compSel', '#compSel', function (){
      multiListGrab($('#compSel'),'',$('#projSel'),0);   
    });
    $(document).off('change.projSel').on('change.projSel', '#projSel',function(){
      multiListGrab($('#projSel'),$('#compSel'),$('#roleSel'),1);
    });
    $(document).off('change.roleSel').on('change.roleSel', '#roleSel', function(){
      multiListGrab($('#roleSel'),$('#projSel'),$('#actSel'),2);
    });
    $(document).off('change.actSel').on('change.actSel', '#actSel', function(){
      multiListGrab($('#actSel'),$('#roleSel'),'',3);
    });
    
    
    //load the selection boxes
    postDict={
      'columns':["DISTINCT companyName"],
      'table':'db.company',
      'dbCall':'select',
      'parseMode':'list',
      'wrapper':'option Selected'
    };
    postBefore=$.post('timetracker.php', postDict);
    postBefore.done(function(data){
      str= "<option value='Any'> Any </option>"
      $('#compSel').empty().append(str+data);
      $('#compSel').change();
    });
    
    
    
    //rig + buttons
    $(document).off('click.addComp').on('click.addComp','#addComp',function(){
      newItem(0);
    });
    $(document).off('click.addProj').on('click.addProj','#addProj',function(){
      newItem(1);  
    });
    $(document).off('click.addRole').on('click.addRole','#addRole',function(){
      newItem(2);
    });
    $(document).off('click.addAct').on('click.addAct','#addAct',function(){
      newItem(3);
    });
    
    
    //rig - buttons
    $(document).off('click.remComp').on('click.remComp','#remComp',function(){
      delItem(0);  
    });
    $(document).off('click.remProj').on('click.remProj','#remProj',function(){
      delItem(1);
    });
    $(document).off('click.remRole').on('click.remRole','#remRole',function(){
      delItem(2);
    });
    $(document).off('click.remAct').on('click.remAct','#remAct',function(){
      delItem(3);
    });
    
    
    //rig edit buttons
    $(document).off('click.edComp').on('click.edComp','#edComp', function(){
      editItem(0);
    });
    $(document).off('click.edProj').on('click.edProj','#edProj',function(){
      editItem(1);
    });
    $(document).off('click.edRole').on('click.edRole','#edRole',function(){
      editItem(2);  
    });
    $(document).off('click.edAct').on('click.edAct','#edAct',function(){
      editItem(3);
    });
  });
}

function loadProfileEdit(){
  getting=$.get('profileEdit.php');
  getting.done(function(data){
    $('#content').empty().append(data);

    
    //rig submit event for profile edit
    $(document).off('submit.profileForm').on('submit.profileForm', '#profileForm', function(){
      event.preventDefault();
      var $form=$(this);
      editProfile($form);
    });
    
    $(document).off('mousedown.showpass').on('mousedown.showpass','#showpass', function(){
       document.getElementsByClassName('pass')[0].type='text';
    });
    $(document).off('mouseup.showpass').on('mouseup.showpass','#showpass', function(){
       document.getElementsByClassName('pass')[0].type='password';
    });
  });  
}
function editProfile($form){ 
  p1=$form.find("input[name='pass1']").val();
  p2=$form.find("input[name='pass2']").val();
  passCur=$form.find("input[name='profilePassword']").val();
  passwordOK=true;
  if(p1!=p2){//ensure both new passwords match before accepting them
    $('#passFix').fadeIn();
    passwordOK=false;
  }
  if(/^[a-zA-Z]*$/.test(p1)==true){
    $('#passStrength').fadeIn();
    passwordOK=false;
  }
  if(p1.length<6){
    passwordOK=false;
    $('#passLength').fadeIn();

  }
  if(p1 == p1.toLowerCase() || p1 == p1.toUpperCase()){
    passwordOK=false;
    $('#passCase').fadeIn();
  }
  alert(passwordOK);
  if(passwordOK==true){
    if(p1!=''){
      postDict={                         //call for password change
        'dbCall': 'editPassword',
        'parseMode':'custome',
        'oldPass': passCur, 
        'newPass': p1
      };
      
      $.ajax({
        type:'POST',
        url:'timetracker.php',
        data: postDict,
        async: false
      }).done(function(data){
        alert(data);
        //clear entry fields 
        $form.find("input[name='pass1']").val('');
        $form.find("input[name='pass2']").val('');
        $form.find("input[name='profilePassword']").val('');
        $('#passFix').fadeOut();//remove password fix notif if present
        $('#passStrength').fadeOut();
        $('#passLength').fadeOut();
        $('#passCase').fadeOut();
        //update user list
      });
    }
  }
}
//Non-Loading Functions
function editItem(fieldNum){
  fields=['comp','proj','role','act'];
  
  //clear all existing fields
  for(i=0;i<4;i++){
    $("#"+fields[i]+"New").fadeOut();
  }
  //load the value from the selected field 
  value=$("#"+fields[fieldNum]+"Sel").val();
  //if the value is not any  & not null
  if(value!=null && $.inArray('Any',value)<0){
    //show text under field X
    $("#"+fields[fieldNum]+"New").fadeIn();
    //show submit/cancel
    $('#sectionConfirm').fadeIn();
    //set val to first selected if multiple are selected
    if(value.length > 1){
      value=value[0];
    }
    $("#"+fields[fieldNum]+"New").val(value)
    //rig onChange to change value if clicked
    $(document).off('change.nameEdit').on('change.nameEdit','#'+fields[fieldNum]+"Sel", function(){
      //get value to change
      newValue=$("#"+fields[fieldNum]+"Sel").val();
      //if it is null, or "any"
      if(newValue==null || $.inArray('Any',newValue)>=0){
        //disable submit
        $('#confirmNewSection').fadeOut();
      }
      else{
        //otherwise allow submit
        $('#confirmNewSection').fadeIn();
        // else set to first value of selection
        if(newValue.length > 1){
          newValue=newValue[0];
        }
        //set the value of the text field to the existing value
        $("#"+fields[fieldNum]+"New").val(newValue)
      }
    });
    //rig Cancel button
    $(document).off('click.newCancel').on('click.newCancel', '#cancelNewSection', function(){
      $(document).off('change.nameEdit');
      $('#confirmNewSection').fadeIn();//fade in to return to normal if faded out
      $("#"+fields[fieldNum]+"New").fadeOut();
      $("#sectionConfirm").fadeOut();
    });
    //rig Confirm button
    $(document).off('click.newSubmit').on('click.newSubmit', '#confirmNewSection', function(){
      editItemSubmit(fieldNum);
      $("#"+fields[fieldNum]+"New").fadeOut();
      $("#sectionConfirm").fadeOut();
    });
  }   
}


function editItemSubmit(fieldNum){
  fields=['comp','proj','role','act'];
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];
  //get current value
  curVal=$("#"+fields[fieldNum]+"Sel").val();
  if(curVal.length>1){
    curVal=curVal[0];
  }
  //get new value
  newVal=$("#"+fields[fieldNum]+"New").val();
  //create post dict
  table=[];
  changes=[];
  
  //edge protection  
  if(fieldNum==0){
    table='db.'+tables[fieldNum];
    changes=[[tables[fieldNum]+"."+catagories[fieldNum], "'"+newVal+"'"]];
  }
  else if(fieldNum==3){
    table='db.'+tables[fieldNum-1];
    changes=[[tables[fieldNum-1]+"."+catagories[fieldNum], "'"+newVal+"'"]];
  }
  else{
    table='db.'+tables[fieldNum]+' NATURAL JOIN db.'+tables[fieldNum-1];
    changes=[[tables[fieldNum]+"."+catagories[fieldNum], "'"+newVal+"'"],
                  [tables[fieldNum-1]+"."+catagories[fieldNum], "'"+newVal+"'"]];
  }
  //edit item name
  postDict={
    'dbCall': 'update',
    'parseMode':'custome',
    'table': table,
    'conditions': [[catagories[fieldNum], '=', "'"+curVal+"'", '']],
    'changes': changes
  };
  posting = $.post('timetracker.php', postDict);
  posting.done(function(data){
    //refresh tables
    postDict={
      'columns':["DISTINCT companyName"],
      'table':'db.company',
      'dbCall':'select',
      'parseMode':'list',
      'wrapper':'option Selected'
    };
    postBefore=$.post('timetracker.php', postDict);
    postBefore.done(function(data){
      str= "<option value='Any'> Any </option>";
      $('#compSel').empty().append(str+data);
      $('#compSel').change();
    });
  });
}

//CREATING NEW COMPANIES
function newItem(fieldNum){
  fields=['comp','proj','role','act'];
  for(i=0;i<4;i++){ //remove any showing fields
    $("#"+fields[i]+"New").fadeOut();
  }
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];
  //Determine Relavent fields
  for(i=fieldNum;i<4;i++){
    //show fields to enter new items into
    value=$("#"+fields[i]+"Sel").val();
    $("#"+fields[i]+"New").fadeIn();
    //show submit/cancel
    $('#sectionConfirm').fadeIn();
    $("#"+fields[i]+"New").val(value);
    //rig onChange to change value if clicked
    $(document).off('change.nameEdit').on('change.nameEdit','#'+fields[i]+"Sel", function(){
      newValue=$("#"+fields[i]+"Sel").val();
      $('#confirmNewSection').fadeIn();
      $("#"+fields[i]+"New").val(newValue)
    });
  }
  //rig cancel
  $(document).off('click.newCancel').on('click.newCancel', '#cancelNewSection', function(){
    $(document).off('change.nameEdit');
    $('#confirmNewSection').fadeIn();
    for(i=fieldNum;i<4;i++){
      $("#"+fields[i]+"New").fadeOut();
    }
    $("#sectionConfirm").fadeOut();
  });
  //rig Confirm
  $(document).off('click.newSubmit').on('click.newSubmit', '#confirmNewSection', function(){
    newItemSubmit(fieldNum);
    for(i=fieldNum;i<4;i++){
      $("#"+fields[i]+"New").fadeOut();
    }
    $("#sectionConfirm").fadeOut();
  });
}

//SUMBIT NEW ITEMS
function newItemSubmit(fieldNum){
  fields=['comp','proj','role','act'];
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];
  fieldVals=[];
  //collect field data
  for(i=0; i<4;i++){
    fieldVals[i]=$('#'+fields[i]+'Sel').val();
    if(i>=fieldNum){
      fieldVals[i]=$('#'+fields[i]+'New').val().split(',');  
    }
    //any option
    /*if($.inArray('Any',fieldVals[i])<0){
      fieldVals[i]=['Select '+ catagories[i] + ' from '+ tables[min(2,i)]];
    }*/
  }
  // parse lists (string to array)
    //comp
  compList=[];
  for(i=0; i<fieldVals[0].length;i++){
    if(fieldVals[0][i]!=''){    
      for(j=0; j<fieldVals[1].length;j++){
        if(fieldVals[1][j]!=''){
	  compList.push([fieldVals[0][i],fieldVals[1][j]]);
	}
      }
    }
  }
    //proj
  projList=[];
  for(i=0; i<fieldVals[1].length;i++){ 
    if(fieldVals[0][i]!=''){    
      for(j=0; j<fieldVals[2].length;j++){
        if(fieldVals[1][j]!=''){
          projList.push([fieldVals[1][i],fieldVals[2][j]]);  
        }
      }
    }
  }
    //role
  roleList=[];
  for(i=0; i<fieldVals[2].length;i++){
    if(fieldVals[0][i]!=''){    
      for(j=0; j<fieldVals[3].length;j++){
        if(fieldVals[1][j]!=''){
          roleList.push([fieldVals[2][i],fieldVals[3][j]]);  
        }
      }
    }
  }         
  //create post comp    
  postDict={
    'table': tables[0],
    'dbCall': 'insertMulti',
    'parseMode':'custome',
    'inserts':[(catagories[0]+', '+catagories[1]), compList]
  };
  posting=$.post('timetracker.php',postDict);
  posting.done(function(data){
    //create post proj
    postDict={
      'table': tables[1],
      'dbCall': 'insertMulti',
      'parseMode':'custome',
      'inserts':[catagories[1]+', '+catagories[2], projList]
    };
    posting=$.post('timetracker.php',postDict);
    posting.done(function(data){
      //create post role
      postDict={
        'table': tables[2],
        'dbCall': 'insertMulti',
        'parseMode':'custome',
        'inserts':[catagories[2]+', '+catagories[3], roleList]
      };
      posting=$.post('timetracker.php',postDict);
      posting.done(function(data){
        //update boxes
        postDict={
          'columns':["DISTINCT companyName"],
          'table':'db.company',
          'dbCall':'select',
          'parseMode':'list',
          'wrapper':'option Selected'
        };
        postBefore=$.post('timetracker.php', postDict);
        postBefore.done(function(data){
          str= "<option value='Any'> Any </option>";
          $('#compSel').empty().append(str+data);
          $('#compSel').change();
        });
      });
    });
  });
}

//DELETE ITEM
function delItem(fieldNum){
  fields=['comp','proj','role','act'];
  //determine selected field
  deleteVal=$('#'+fields[fieldNum]+'Sel').val();
  //YES/NO for deleting related items
  if(confirm('Delete items '+deleteVal+'?')){  
    if(confirm('Delete Related Items?')){
      deleteRecursionStart(deleteVal, fieldNum);
    }
    else{
      //get values
      for(var i=0; i<deleteVal.length;i++){
        deleteItem(deleteVal[i],fieldNum);
      }
      //delete  
      postDict={
        'columns':["DISTINCT companyName"],
        'table':'db.company',
        'dbCall':'select',
        'parseMode':'list',
        'wrapper':'option Selected'
      };
      //ajax helps prevent crossovers in POST
      $.ajax({
        type:'POST',
        url:'timetracker.php',
        data: postDict,
        async:false
      }).done(function(data){
        str= "<option value='Any'> Any </option>";
        $('#compSel').empty().append(str+data);
        $('#compSel').change();
      });
    }
  }
}

//RELATED ITEM DELETION START  
function deleteRecursionStart(items, fieldNum){
  for(i=0;i<items.length;i++){//start the reel manually 
    var related=retrieveRelatedItems(items[i], fieldNum);
    deleteItem(items[i], fieldNum);
    deleteRecursion(related[1], fieldNum+1, false);//start right branch
    deleteRecursion(related[0], fieldNum-1, true);//start left branch
  }
  //Update tables
  postDict={
    'columns':["DISTINCT companyName"],
    'table':'db.company',
    'dbCall':'select',
    'parseMode':'list',
    'wrapper':'option Selected'
  };
  $.ajax({
    type:'POST',
    url:'timetracker.php',
    data: postDict,
    async:false
  }).done(function(data){
    str= "<option value='Any'> Any </option>";
    $('#compSel').empty().append(str+data);
    $('#compSel').change();
  });
}

//recursive calling for deleting related items
function deleteRecursion(items, fieldNum, left){
  fields=['comp','proj','role','act'];
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];  
  if(fieldNum>3||fieldNum<0){                 //stop if out of range
    return false;
  }
  for(var k=0;k<items.length;k++){
    if(!items[k]==''){
      deleteCore(items[k], fieldNum, left);    //otherwise look threw list and branch on each item
    }
  }
}
//main logic to deleting
function deleteCore(item, fieldNum, left){
  var remaining=retrieveRelatedItems(item, fieldNum);
  //debug line, shows items related and their length
  //alert('delete '+item+ ' from field '+fields[fieldNum]+ ' and related items ('+ remaining[0]+')'+remaining[0].length+' and ('+ remaining[1] +')'+remaining[1].length);
  
  if((remaining[1].length<1 && remaining[0].length<1)|| //if nothing is related OR
      (remaining[1].length<1 && fieldNum<3)|| //if not at end and not realated to after OR
      (remaining[0].length<1 && fieldNum>0)){ //if not at start and not related to before
    deleteItem(item, fieldNum); //delete item
  }
  if(!left){//branch right
    deleteRecursion(remaining[1], fieldNum+1, false);
  }
  
  if(left){//branch left
    deleteRecursion(remaining[0], fieldNum-1, true);
  }
}

//submit to database the deletions
function deleteItem(item, fieldNum){
  fields=['comp','proj','role','act'];
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];
  str="('";
  var deletables=[];
  //obtain catagories to delete from
  if(fieldNum>0){
    deletables = $('#'+fields[fieldNum-1]+'Sel').val();
  }
  if($.inArray('Any',deletables)>=0){
    deletables = [];
  }
  //alert('deletion:'+item+':('+deletables+')');
  //build to a list
  for(var i=0;i<deletables.length;i++){
    str+=deletables[i]+"', '";  
  }
  str=str.slice(0,str.length-3)+')';
  
  //submit to database for deletion in current table
  postDict={
    'dbCall':'delete',
    'table': tables[Math.min(fieldNum,2)],
    'conditions': [[catagories[fieldNum],'=',"'"+item+"'",'']]
  }
  if(deletables.length>0){
    postDict['conditions']=[[catagories[fieldNum],'=',"'"+item+"'",'AND'],
                              [catagories[fieldNum],'IN',str,'']];    
  }
  $.ajax({
    type:'POST',
    url:'timetracker.php',
    data: postDict,
    async: false
  });
  //delete from preceeding table
  postDict['table']=tables[Math.max(fieldNum-1,0)];
  postDict['conditions']=[[catagories[fieldNum],'=',"'"+item+"'",'AND'],
                              [catagories[fieldNum-1],'IN',str,'']]; 
  //alert(deletables);
  
  $.ajax({type:'POST',
          url: 'timeTracker.php', 
          data: postDict,
          async: false
  });
}

//Get Items Related to current deletion
function retrieveRelatedItems(item,fieldNum){
  fields=['comp','proj','role','act'];
  tables=['company', 'project', 'roles'];
  catagories=['companyName', 'projectName', 'roleName', 'activity'];
  var prev=[];
  var next=[];
  //select related from current table (Current, Related)
  postDict={
    'dbCall':'select',
    'parseMode':'bland',
    'columns':["DISTINCT "+catagories[Math.min(fieldNum+1,3)]],
    'table': tables[Math.min(fieldNum,2)],
    'conditions': [[catagories[fieldNum],'=',"'"+item+"'",'']] 
  };
  //dont pull from field 4 (doesnt exist)
  if(fieldNum+1 < 4){
    //get items from next field
    $.ajax({
      type: 'POST',
      url: 'timetracker.php', 
      data: postDict,
      async: false
    }).done(function(data){
        next=data.split(',');  
        for(var i=0; i<next.length;i++){
          if(next[i]==''){
            next.splice(i,i+1);  
          }
          else{
            i++;
          }
        }
    });
  }
  postDict={
    'dbCall':'select',
    'parseMode':'bland',
    'columns':["DISTINCT "+catagories[Math.max(fieldNum-1,0)]],
    'table': tables[Math.max(fieldNum-1,0)],
    'conditions': [[catagories[fieldNum],'=',"'"+item+"'",'']] 
  };
  //get items from prev field
  $.ajax({
    type:'POST',
    url:'timetracker.php',
    data: postDict,
    async: false
  }).done(function(data){
    prev=data.split(',');
    var i=0;
    //alert(prev+':'+next);
    while(i<prev.length){
      //alert(prev[i]+':'+$.inArray(prev[i],prevVal));
      if(prev[i]==''){
        prev.splice(i,i+1);  
      }
      else{
        i++;
      }
    }
  });
  
  return[prev, next];
  
}

//EDIT TIMETRACKER ROW
function editRow(entryID, user, eTable){
  rowID=entryID+eTable;
  //pull table values and place into edit form
  $('#editUser').val(user);
  $('#editID').val(entryID);
  if(eTable=='entry'){
    $('#editTable').val('db.'+eTable);
  }
  else{
    $('#editTable').val('temp.'+eTable);
  }
  tStart=$(('#'+rowID+' .timeStart')).find("time").attr('datetime');
  tEnd=$(('#'+rowID+' .timeStop')).find("time").attr('datetime');
  $('#editSDate').val(dateTrimR(tStart));  
  $('#editEDate').val(dateTrimR(tEnd));
  listGrab('','companyName','company','','#editComp',$(('#'+rowID+' .companyName')).html());
  listGrab('companyName','projectName','company','#editComp','#editProj',$(('#'+rowID+' .projectName')).html());
  listGrab('projectName','roleName','project','#editProj','#editRole',$(('#'+rowID+' .roleName')).html());
  listGrab('roleName','activity','roles','#editRole', '#editAct',$(('#'+rowID+' .activity')).html());
  $('#editNotes').val($(('#'+rowID+' .notes')).html());
  $('#editBug').val($(('#'+rowID+' .issue')).html());
  
  
  //rig delete button
  $(document).off('click.editDel').on('click.editDel', '#editDel', function(){
      if(confirm('Delete this entry?')){
	deleteEntryRow();
      }
  });
  $(document).off('click.editCan').on('click.editCan','#editCan', function(){
    $('#editDiv').fadeOut();
  });  
  
  //rig edit form submit button
  $( "#editForm" ).submit(function( event ) {
    event.preventDefault();       //conjoined with new entry due to similarities
    var $form = $(this);
    submit($form, 'update');
    $('#editDiv').fadeOut();
  });
  $('#editDiv').fadeIn();
} 

//remove the row 
function deleteEntryRow(){
  table= $('#editTable').val();
  row=$('#editID').val();
  postDict={
    'dbCall': 'delete',
    'parseMode':'custome', 
    'table':table,
    'conditions':[['entryID', '=', "'"+row+"'", '']]
  };
  posting = $.post('timetracker.php', postDict);
  posting.done(function (data){
    $('#editDiv').fadeOut();
    if($('#fullSearch').length){
    search($('#fullSearch'));
    }
    else{
      user=form.find("input[name='uname']").val();
      entryCheck([['1','=','1',''],['ORDER BY', 'timeStart','DESC','']], user);
      
    }
  });
}

//load user information for edit
function loadUser(){
  $('#confirmation').fadeOut();
  postDict={
    'dbCall':'loadUser',
    'parseMode':'userInfo',
    'uName': $('#userDBResults').val()
  };
  if($('#userDBResults').val()!='New User'){
    posting= $.post('timetracker.php',postDict);
    posting.done(function (data){
      $('#userInfo').empty().append(data);  
    });
  }
  else{
    form=$('#userForm');
    form.find("input[name='uname']").val(''); 
    form.find("input[name='pass1']").val('');
    form.find("input[name='pass2']").val('');
    form.find("input[name='fName']").val('');
    form.find("input[name='lName']").val('');
  }
}

//deletes a user
function deleteUser(){
  postDict= {
    'dbCall': 'delUser',
    'parseMode':'delNotif',
    'uName': $('#userDBResults').val(),
    'pWord': $('#removePassword').val()    
  };
  posting = $.post('timetracker.php',postDict);
  
  posting.done(function(data){
    //clear the password field
    $('#removePassword').val('');
    //refresh user list
    listGrab('','user','mysql.user','','#userDBResults','New User');
  });  
  
}

function updateUser($form){
  oldName=$('#userDBResults').val();
  uName=$form.find("input[name='uname']").val();
  fName=$form.find("input[name='fName']").val();
  lName=$form.find("input[name='lName']").val();
  p1=$form.find("input[name='pass1']").val();
  p2=$form.find("input[name='pass2']").val();
  moderator=$form.find("input[name='modbox']").prop('checked');
  if(oldName!=uName){
    updateUserName(oldName, uName);
  }
  if(p1.length>0){
    if(p1!=p2){//ensure both passwords match before accepting them
      $('#passFix').fadeIn();
    }
    else{
      adminUpdatePassword(uName, p1);
    }  
  }
  updatePermissions(uName, moderator);
  updateEmployeeTable(oldName, uName, fName, lName);
  $('#userDBResults').val(uName).change();
  alert('updated '+uName);
}

function adminUpdatePassword(uName, password){
  postDict={
    'dbCall': 'adminPass',
    'parseMode':'custome', 
    'uName': uName,
    'pass':password
  };
  response=waitingAjax(postDict);
  //alert("adminPasswordSet: "+response);  
}
function updatePermissions(uName, moderator){
  postDict={
    'dbCall': 'updatePerm',
    'parseMode':'custome', 
    'uName': uName,
    'mod': moderator
  };
  response=waitingAjax(postDict);
  //alert("updatePersmissions: "+response);
}
function updateUserName(oldName, newName){
  postDict={
    'dbCall': 'updateName',
    'parseMode':'custome',                       
    'oldName': oldName,
    'newName': newName           
  };
  response=waitingAjax(postDict);
  //alert("updateName: "+ response);
}
function updateEmployeeTable(oldName, uName, fName, lName){
  postDict={
    'dbCall': 'updateEmployee',
    'parseMode':'custome', 
    'uName':uName,
    'fName':fName,
    'lName':lName,
    'oldName':oldName
  };
  response=waitingAjax(postDict);
  //alert("updateEmployee: " +response);
}
//creates a user
function createUser($form){
  uName=$form.find("input[name='uname']").val(); 
  p1=$form.find("input[name='pass1']").val();
  p2=$form.find("input[name='pass2']").val();
  if(p1!=p2){//ensure both passwords match before accepting them
    $('#passFix').fadeIn();
  }
  else{
    postDict={
      'dbCall': 'newUser',
      'parseMode':'creNotif',
      'uName': uName,
      'pWord': p1,
      'mod': $form.find("input[name='modbox']").prop('checked'), 
      'fName': $form.find("input[name='fName']").val(),
      'lName': $form.find("input[name='lName']").val()
    };
    posting=$.post('timetracker.php',postDict);
    posting.done(function(data){
      //clear entry fields
      alert(data);
      $form.find("input[name='uname']").val(''); 
      $form.find("input[name='pass1']").val('');
      $form.find("input[name='pass2']").val('');
      $form.find("input[name='fName']").val('');
      $form.find("input[name='lName']").val('');
      $('#passFix').fadeOut();//remove password fix notif if present
      //update user list
      listGrab('','user','mysql.user','','#userDBResults','New User');
    });
  }
}


//SUBMIT
// handles dictionary partial creation for update and insert
function submit(form, mode){
  table=form.find("input[name='table']").val();
  if(!table){
    table='temp.'+form.find("input[name='uname']").val();
  }
  dataType='';
  timeStart=dateTrim(form.find("input[name='sdate']").val());
  timeEnd=dateTrim(form.find("input[name='edate']").val());  
  formData=[
    ['employeeID',parseHelper(form.find("input[name='uname']").val())],
    ['companyName',parseHelper(form.find("select[name='comp']").val())],
    ['projectName',parseHelper(form.find("select[name='proj']").val())],
    ['roleName',parseHelper(form.find("select[name='role']").val())],
    ['activity',parseHelper(form.find("select[name='act']").val())],
    ['issue',parseHelper(form.find("input[name='bug']").val())],
    ['notes',parseHelper(form.find("textarea[name='notes']").val())],
    ['timeStart',timeStart],
    ['timeStop',timeEnd]
  ];
  postDict={
    'dbCall': mode,
    'parseMode':'custome',
    'table': table    
  };
  if(mode=='update'){
    postDict['changes']=formData;
    postDict['conditions']=[['entryID','=', form.find("input[name='rowID']").val(),'']];
  }
  else if(mode=='insert'){
    postDict['inserts']=formData;
  }
  timeStart= new Date(timeStart.substring(1,12));
  timeEnd= new Date(timeEnd.substring(1,12));
  weekStart= new Date();
  weekEnd= new Date();
  weekStart.setDate(weekStart.getDate()-weekStart.getDay());
  weekEnd.setDate(weekStart.getDate()+7);
  if(timeStart<weekStart||timeStart>weekEnd||timeEnd<weekStart||timeEnd>weekEnd){
    $('#timeAlert').fadeIn();
  }
  else{
    $('#timeAlert').fadeOut();
    posting=$.post('timetracker.php',postDict);
    posting.done(function(data){
      //alert(data);
      //refresh edited/inserted table
      if($('#fullSearch').length){
        search($('#fullSearch'));
      }
      else{
        user=form.find("input[name='uname']").val();
        form.find("textarea[name='notes']").val('');
        form.find("input[name='bug']").val('');
        form.find("select[name='role']").val('');
        form.find("select[name='act']").val('');
        form.find("input[name='sdate']").val(form.find("input[name='edate']").val());
        entryCheck([['1','=','1',''],['ORDER BY', 'timeStart','DESC','']], user);
      }
    });
  }
}   
//Pulls the lists for the add/edit/delete company/project/role/activity table
function multiListGrab(now, before, after, tableNum){
  tables=['company','project','roles'];
  catagories=['companyName','projectName','roleName','activity'];
  conditions=[];
  nowVal=now.val();
  if((nowVal!=null)){
    if(($.inArray('Any',nowVal)<0)){
      for(i=0;i<nowVal.length;i++){
        conditions[i]=[catagories[tableNum], '=',"'"+nowVal[i]+"'",'OR']
      }
      conditions[conditions.length-1][3]='';   
    }
    postDict={
      'columns':["DISTINCT "+catagories[tableNum-1]],
      'table':tables[tableNum-1],
      'dbCall':'select',
      'parseMode':'list',
      'wrapper':'option '
    };
    if(conditions.length>0){
      postDict['conditions']=conditions;
    }
    
    //Reverse feature, if the use selects a value and before is "ANY" highlight the fields with the selected value *TO FIX*
    if((before!='')&&($.inArray('Any',before.val()))){
      //build before postDict
      //alert(tableNum+":"+postDict['conditions']);
      //postMultiList(postDict, before, false);  
    }
    
    if(after!=''){
      postDict['columns']=["DISTINCT "+catagories[tableNum+1]];
      //alert("NEXT-BEFORE:"+after.val());
      postDict['table']=tables[tableNum];    
      postDict['wrapper']='option Selected ';
      postMultiList(postDict, after, true);
    }
  }
  else{
    $(after).empty().append(str);
    $(after).change();
  }
}
 //Submit compiled section params to .php and database
function postMultiList(postDict, location, change){
  str= "<option value='Any'> Any </option>";
  posting=$.post('timetracker.php', postDict);
  posting.done(function(data){ 
    $(location).empty().append(str+data); 
    if(change){        
      $(location).change();
    }
  });  
}

//pulls a list for the insert/update entry fields
function listGrab(parent, child, table, key, location, val){
  str = '';
  str ="'%"+$((key)).val()+"%'";
  postDict= {
      'columns':["DISTINCT "+child],
      'table':table,
      'dbCall':'select',
      'parseMode':'list', 
      'wrapper':"option "
    }
  if(parent!=''&&key!=''){
    postDict['conditions']=[[parent,'LIKE',str,'']];
  }  
  $.ajax({
      type: 'POST',
      url: 'timetracker.php', 
      data: postDict,
      async: false
  }).done(function (data){
    if(val=='New User'){
      str= "<option selected> "+val+" </option>"
    }
    else{ 
      str= "<option selected disabled value='null'> "+val+" </option>"
    }
    $(location).empty().append(str+data);
    $(location).val(val);
    $(location).change();
  });
}

//Compiles things for the quicksearch button in the header and passes them to the search function
function quickSearch(form){
  var fullForm = $('#fullSearch');
  fullForm.find("input[name='sdate']").val($('#QSsDate').val());
  fullForm.find("input[name='edate']").val($('#QSeDate').val());
  fullForm.find("input[name='fname']").val($('#QSfName').val());
  fullForm.find("input[name='lname']").val($('#QSlName').val());
  fullForm.find("input[name='uname']").val($('#QSuName').val());
  search(fullForm);
}

//adds on syntax for the X LIKE Y function in MySQL, % allows any set of characters to be appended onto the side, making partial search possible
function likeParseAid(string){
  return "'%"+string+"%'";
}

//compiles the search form 
function search(form){
  user=form.find("input[name='uname']").val();
  conditions=[
    ['employeeID','LIKE',likeParseAid(user),'AND'],
    ['firstName','LIKE',likeParseAid(form.find("input[name='fname']").val()),'AND'],
    ['lastName','LIKE',likeParseAid(form.find("input[name='lname']").val()),'AND'],
    ['companyName','LIKE',likeParseAid(form.find("input[name='comp']").val()),'AND'],
    ['projectName','LIKE',likeParseAid(form.find("input[name='proj']").val()),'AND'],
    ['roleName','LIKE',likeParseAid(form.find("input[name='role']").val()),'AND'],
    ['notes','LIKE',likeParseAid(form.find("textarea[name='notes']").val()),'AND'],
    ['(timeStart',"<",dateTrim(form.find("input[name='edate']").val()),'AND'],
    ['timeStop','>',dateTrim(form.find("input[name='sdate']").val()),')'],
    ['ORDER BY', 'timeStart DESC, timeStop DESC, companyName ASC, projectName ASC, roleName ASC, activity ASC, issue ASC, notes ASC, timeSpent','ASC','']
  ];
  entryCheck(conditions, user);
}

//submits the search form or a default to the php and database
function entryCheck(conditions, user){
  //database scan
  postDict={
    'dbCall':'select',
    'table':'db.entry',
    'conditions':conditions,
    'parseMode':'entryTable',
    'eTable':'entry'
  }
  if($('#coreDBResults').length){//if core DB is displayed currently
    postPage(postDict,'#coreDBResults');
    //alert('scan main');
  }
  //temp scan
  postDict['table']=('temp.'+user);
  postDict['eTable']=user;
  postDict['editable']=true;
  if($('#tempDBResults').length){//if temp DB is displayed currently
    postPage(postDict,'#tempDBResults');
    //alert('scan temp');
  }
} 

//allows users to save the current search from the databases (only available on search.php)
function save(section){
  form=$('#saveSearch');
  user=$("#suname").val();
  table='temp.'+user+'View';  
  if(section=='Main'){
    table='db.entryView';  
  }
  $("#stable").val(table);
  form.submit();
  
}

//basic GET call
function getPage(pageFile,location){
  getting=$.get(pageFile);
  getting.done(function(data){
    //alert(data);
    $(location).empty().append(data);
  });
}

//basic POST call (only to timetracker.php)
function postPage(postDict, location){
  posting=$.post('timetracker.php',postDict);
  posting.done(function(data){
    //alert(data);
    $(location).empty().append(data);
  });
}

//wraps strings in '' to aid in MySQL parsing
function parseHelper(string){
  return "'"+string+"'";
}

//converts from the html datetime to mysql datetime
function dateTrim(date){  
  return "'"+date.substring(0,10)+' '+date.substring(11,date.length)+":00'";
}
//converts from the mysql/php datetime to html datetime
function dateTrimR(date){
  return date.substring(0,10)+'\T'+date.substring(11,16);
}

//ajax non-async call
function waitingAjax(postDict){
  $.ajax({
    type:'POST',
    url:'timetracker.php',
    data: postDict,
    async: false
  }).done(function(data){
    //alert(data);
  });
}
//main page functions

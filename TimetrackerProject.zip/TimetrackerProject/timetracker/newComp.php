<!DOCTYPE html>
<html>
<head>
<?php 
  session_start();
  $_SESSION['landing']='newComp';
?>
<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
</head>
<body>
  <!-- company full table-->
  <table>
    <tr>
      <!-- section headers -->
      <th>Company</th>
      <th>Project</th>
      <th>Role</th>
      <th>Activity</th>
    </tr>
    <tr>
      <!-- section contents -->
      <td>
        <select id='compSel' multiple></select>
      </td>
      <td>
        <select id='projSel' multiple></select>
      </td>
      <td>
        <select id='roleSel' multiple></select>
      </td>
      <td>
        <select id='actSel' multiple></select> 
      </td>
    </tr>
    <tr>
      <!-- section buttons -->
      <td>
        <button type="button" id='addComp'>+</button>
        <button type="button" id='edComp'>Edit</button>
        <button type="button" id='remComp'>-</button>
      </td>
      <td>
        <button type="button" id='addProj'>+</button>
        <button type="button" id='edProj'>Edit</button>
        <button type="button" id='remProj'>-</button>
      </td>
      <td>
        <button type="button" id='addRole'>+</button>
        <button type="button" id='edRole'>Edit</button>
        <button type="button" id='remRole'>-</button>
      </td>
      <td>
        <button type="button" id='addAct'>+</button>
        <button type="button" id='edAct'>Edit</button>
        <button type="button" id='remAct'>-</button>
      </td>
    </tr>                    
    <tr id='newSection' >
      <!--section entry fields-->
      <td>
        <input id='compNew' style='display: none;'>
      </td>
      <td>
        <input id='projNew' style='display: none;'>
      </td>
      <td>
        <input id='roleNew' style='display: none;'>
      </td>
      <td>
        <input id='actNew' style='display: none;'>
      </td>
    </tr>
    <tr id='sectionConfirm' style='display: none;'>
      <!-- Confirmation/Cancel Buttons -->
      <td>
        <button type='button' id='confirmNewSection'>Confirm</button>
      </td>
      <td>
      </td>
      <td>
      </td>
      <td>
        <button type='button' id='cancelNewSection'>Cancel</button>
      </td>
    </tr>
</body>

<?php
  //php settings (session/timezone/errors)
  
  //MAIN FUNCTION
  session_start(); // connect to active session
  date_default_timezone_set('America/Chicago'); // ensure we are in chicago timezone
  error_reporting(E_ALL ^ E_NOTICE); //snuff warnings of unused variables
  $postCall=checkPost('dbCall','varFill','default');  //pull and sanitize the type of action to be done
  $parseMode=checkPost('parseMode','varFill','custome'); //pull and sanitize the type of parsing (output formatting) to be done
  $returnable=poster($postCall,$parseMode); // set up the return item with the parsed data
  echo $returnable; //output data
  
  
  // takes the type of action and parse and returns the formatted results from the Database call
  function poster($dbCall, $parseMode){
    $query=call_user_func(($dbCall.'Post'));//build the query based on the type of call in "$dbCall"
    if(isset($query)){// ensure query is set before bugging the database about it
     //echo $query.','; // debug line (displays query)
      $data = database($query); //call the database and send the query
      if(!isset($data)){ //check if the database returned anything              
        return "BAD REQUEST: $query"; //if not return the query to the user for analysis
      }  
      
      //these lines only run if the function returns the data as "return" terminates the function
      $parsed=call_user_func(($parseMode.'Parse'),$data); //call a function to format the returned data E.G. blandParse()
      return $parsed; //return the formatted data
    }
  }
  
  
  //Connects to the database, passes the query, and returns either the raw results or nothing
  function database($query){
    $conn = new mysqli("localhost",$_SESSION['User'],$_SESSION['Pass'],"db");// connect to the db with the active user's name and password
    //echo $query;
    $data = mysqli_query($conn, $query);//execute the command compiled earlier
    echo $conn->error; //display errors in the output if they occured
    $conn->close(); //close connection to the database
    if($data){
      return $data; //return the data if it exists
    }
    else{
      return null; //otherwise return nothing
    }
  }
  
  

  
  //POST READERS (checks post for variables, calls formatting functions, and passes them to the query builders)
    
  function defaultPost(){ //dummy function, returns blank subsequently ending the php script
    return null;
  }
  
  function selectPost(){//formats a select for the entry views, and creates the views and tables for the temp entries
    $table=checkPost('table','tablePhrase','db.entry');//check for the table to search, and pass it to tablePhrase(), if it isnt there return 'db.entry'
    $columns=checkPost('columns','columnsPhrase','*');//check for the columns to search, and pass them to columnsPhrase(), or pass back '*' (wildcard, matches and returns all columns)
    $conditions = checkPost('conditions','conditionsPhrase','1=1');//check for the conditional statements, and pass them to conditionsPhrase(), or pass back '1=1' which tautologically allows all rows to pass the check
    if((strpos($table,'db.entry')!==false)||(strpos($table,'temp.')!==false)){//if the table is a temp entry or the "db.entry table" format it to use the view instead
              //check for the phrase 'db.entry' in string $table, if the result is not explicitly false then continue
      $view=$table.'View';//append the view
      testView($table, $view);//check for the view and ensure it exists, if not create it
      $table=$view;//set the view to be returned
    }
    return selectPhrase($columns, $table, $conditions);//return table   
  }
  
  //The rest of the post readers follow a format of 
    //check the variables needed, sanatize them or return the defaults if they dont exists
    //ship them to the query builder and return what it gives back
    
  
  function createPost(){
    $table=checkPost('table','varFill',('temp.'.$_SESSION['User']));
    $newValues=checkPost('newValues', 'newValuesPhrase','');
    return tempCreatePhrase($table, $newValues);
  }
  function updatePost(){//uses a table, the changes to be made (catagories and the values to set them to), and a conditional statement for when to be changed
    $table=checkPost('table','tablePhrase','db.entry');
    $changes=checkPost('changes','changePhrase','');
    $conditions=checkPost('conditions','conditionsPhrase','1=1');
    return updatePhrase($table, $changes, $conditions);
  }
  function insertPost(){//uses a table and the values to be added into it (which consist of the catagories and values in the same array)
    $table=checkPost('table','tablePhrase','db.entry');
    $inserts=checkPost('inserts','insertListPhrase',['','']);
    return insertPhrase($table, $inserts[0], $inserts[1]);
  }
  function insertMultiPost(){//similar to above, but uses an "OR IGNORE" to prevent duplicates
    $table=checkPost('table','tablePhrase','db.entry');
    $inserts=checkPost('inserts','insertMultiParse', ['','']);
    return insertIgnorePhrase($table, $inserts[0],$inserts[1]);
  }
  function deletePost(){//uses a table and conditions statement to remove items from a table
    $table=checkPost('table','tablePhrase','');
    $conditions=checkPost('conditions','conditionsPhrase','1=1');
    return deletePhrase($table, $conditions);
  }
  function delUserPost(){//uses a username and password to delete the corresponding user from account access (leaves the user in the database for records purposes)
    $user=checkPost('uName','varFill', null);
    $pass=checkPost('pWord','varFill', null);
    return delUserPhrase($user, $pass);
  }
  function newUserPost(){//uses a username, password, first name, last name, and a true/false moderator status to implement a new user
    $user=checkPost('uName','varFill', null);
    $pass=checkPost('pWord','varFill', null);
    $mod =checkPost('mod','varFill', False);
    $fName=checkPost('fName','varFill','');
    $lName=checkPost('lName','varFill','');
    return newUserPhrase($user, $pass, $mod, $fName, $lName);
  }
  function editPasswordPost(){//uses a password and new password to edit the accounts password
    $oldPass=checkPost('oldPass', 'varFill', '');
    $newPass=checkPost('newPass', 'varFill', '');
    if($oldPass==$_SESSION['Pass']){
      return editPasswordPhrase($newPass);
    }                                           
    else{
      exit("BAD PASSWORD");
    }
    
  }
  function loadUserPost(){
    $uName=checkPost('uName', 'varFill', null);
    return loadUserPhrase($uName);
  }
  function adminPassPost(){
    $uName=checkPost('uName','varFill',null);
    $pass=checkPost('pass', 'varFill', null);
    return adminPassPhrase($uName, $pass);
  }
  function updatePermPost(){
    $uName=checkPost('uName','varFill',null);
    $mod=checkPost('mod', 'varFill', False);
    database(deletePermPhrase($uName));
    database(genPermPhrase($uName));
    if($mod=='true'){
      return modPermPhrase($uName);
    }
    else{
      return "flush PRIVILEGES";
    }
  }
  function updateNamePost(){
    $oldName=checkPost('oldName','varFill',null);
    $uName=checkPost('uName', 'varFill', null);
    return updateNamePhrase($oldName, $uName);
  }
  function updateEmployeePost(){
    $user=checkPost('uName','varFill', null);
    $fName=checkPost('fName','varFill','');
    $lName=checkPost('lName','varFill','');
    $oldName=checkPost('oldName','varFill','');
    return updateEmployeePhrase($user, $fName, $lName, $oldName);
  }
  //CHECK POST FUNCTION
    //checks for the posted variable, sanitizes it, then if it is blank or missing returns the given default
    // if it exists it passes the variable along to the designated function
    
  function checkPost($postVar, $function, $default){
    if((!isset($_POST[$postVar]))||$_POST[$postVar]==null){//check if the variable exists and isnt null
      //echo 'var not found: '.$postVar; // debug line, prints any variables not found
      return $default;
    }
    $returnable= call_user_func($function, $_POST[$postVar]); //calls the given function (should be a sanatizing function) and submits the variable to it
    if($returnable==''){//ensure that sanatized variable is not hollow
      return $default;  
    }
    return $returnable;
  }
  
  
  
  
  
  
  //QUERY BUILDERS
    //formats the data for the database calls
  
  //get entry (SELECT * FROM db.entry NATURAL JOIN db.employee WHERE [conditions])
  function selectPhrase($columns, $table, $conditions){
    return "Select $columns FROM $table WHERE $conditions";
  }
  //update entry (UPDATE table SET [catagory=value] WHERE [conditions])
  function updatePhrase($table, $change, $conditions){
    return "UPDATE $table SET $change WHERE $conditions";
  }
  //insert entry (INSERT INTO temp.$user (employeeID, companyName, projectName, roleName, activity, issue, notes, timeStart,timeStop)
  //                VALUES ($uName,$comp,$proj,$role,$act,$issue,$note,$sDate,$eDate))
  function insertPhrase($table, $catagories, $values){
    return "INSERT INTO $table $catagories VALUES $values";
  }
  function insertIgnorePhrase($table, $catagories, $values){
    return "INSERT IGNORE INTO $table $catagories VALUES $values";
  }
  //delete entry (DELETE FROM table WHERE [conditions])
  function deletePhrase($table, $conditions){
    return "DELETE FROM $table WHERE $conditions";
  }
  //create table (CREATE TABLE table (field1,field2,field3,field...))
  function tempCreatePhrase($table, $newValues){
    return "CREATE TABLE $table $newValues";
  }
  //delete user (DELETE FROM mysql.user WHERE conditions==true AND/OR conditions!=false)
  function delUserPhrase($uname, $pass){
    $parseMode = 'deletion';
    return "Select User from mysql.user where User='$uname' AND Password=Password('$pass')"; 
  }
  function loadUserPhrase($uname){
    return "select employeeID, firstName, lastName, Select_priv from mysql.user, db.employee where employeeID=user and user='$uname'";
  }
  function adminPassPhrase($oldName, $pass){
    return "set password for '$oldName'@'localhost' = PASSWORD('$pass')";
  }
  function updateEmployeePhrase($uName, $fName, $lName, $oldName){
    return "update db.employee SET employeeID='$uName', firstName='$fName', lastName='$lName' where employeeID='$oldName'";
  }
  function genPermPhrase($uName){
    database("Grant all on temp.* to '$uName'@'localhost'");
    return "Grant SELECT, Create View on db.* to '$uName'@'localhost'";
  }
  function modPermPhrase($uName){
    database("Grant all on db.* to '$uName'@'localhost' with Grant option");
    database("Grant all on c.* to '$uName'@'localhost' with grant option");
    database("Grant SELECT on *.* to '$uName'@'localhost' with grant option");
    database("Grant reload, create user on *.* to '$uName'@'localhost' with grant option");
    return "flush PRIVILEGES";
  }
  function deletePermPhrase($uName){
    return "revoke all privileges, grant option from '$uName'@'localhost'";
  }
  function updateNamePhrase($oldName,$uName){
    return "rename user '$oldName'@'localhost' to '$uName'@'localhost'";
  }
  
  //create newuser (Calls a predefined function described in the database, this is set up in the .SQL file)
  function newUserPhrase($uname, $pass, $mod, $fname, $lname){
    return "CALL newUser('$uname', '$pass', '$fname', '$lname', $mod);";
  }
  function editPasswordPhrase($newPass){
    $query="SET PASSWORD = password('$newPass')";
    $data = database($query); //call the database and send the query
    if(!isset($data)){ //check if the database returned anything              
      exit("BAD REQUEST: $query"); //if not return the query to the user for analysis
    } 
    $_SESSION['Pass']=$newPass;
    exit('Password Changed');
  }
  
  //SUBQUERY BUILDERS
    //formats the variables for the query builder functions
  
  
  //COLUMNS 
    //input: array of strings [table 1, table 2, table 3]
    //output: comma seperated table names "column1, column2, column3" 
  function columnsPhrase($columns){
    $str='';
    foreach($columns as $column){
      $column=varFill($column);
      if(isset($column)){
        $str.=" $column,";
      }
    }
    return substr($str, 0, -1);
  }
  
  //TABLE NAME
    //creates the temp tables if they do not exist 
  function tablePhrase($table){
    $table=varFill($table);
    if($table=='temp.'){
    	echo "<h3>No Results</h3>";
	exit();
    }
    if(strpos($table,'temp')!==false){
      database("CREATE TABLE IF NOT EXISTS $table (entryID INT UNSIGNED NOT NULL AUTO_INCREMENT, employeeID varchar(20) NOT NULL REFERENCES Employee(employeeID),companyName VARCHAR(100) NOT NULL REFERENCES Company (companyName),projectName VARCHAR(100) NOT NULL REFERENCES Project (projectName),roleName VARCHAR(100) REFERENCES Roles(roleName), activity VARCHAR(100) REFERENCES Roles(activity), issue VARCHAR(256), notes VARCHAR (256), timeStart DATETIME NOT NULL, timeStop DATETIME NOT NULL, PRIMARY KEY (entryID), UNIQUE(employeeID, companyName, projectName, roleName, activity, timeStart, timeStop))");
    }
    return $table;
  }                                                
  
  //LIST OF CATAGORIES
    //input: Nested array of strings [[catagory1, input1], [catagory2, input2], ...]
    //output: array of 2 strings ["(catagory1, catagory 2, ...)", "(input1, input2, ...)"]
  function insertListPhrase($insertArray){
    $catagoryList='(';
    $valueList='(';
    foreach($insertArray as $inserts){
      $catagory=varFill($inserts[0]);
      $value=varFill($inserts[1]);
      $catagoryList.="$catagory, ";
      $valueList.="$value, ";
    }
    //echo $catagoryList.":".$valueList;
    return [(substr($catagoryList,0,-2).")"),(substr($valueList,0,-2).")")];
  }
  
    //input: Array with catagories and nested arrays of inputs [[catagory1, catagory2, ...],[[input1-1, input1-2, ...],[input2-1,input2-2, ...], ...]]
    //output: array of 2 strings ["(catagory1, catagory2, ...)", "(input1-1, input1-2, ...),(input2-1, input2-2, ...)"]
  function insertMultiParse($insertArray){
    $catagoryList='('.varFill($insertArray[0]).')';
    $valueList='(';
    foreach($insertArray[1] as $item){
      foreach($item as $elem){
        $valueList.="'$elem', ";  
      }
      $valueList=(substr($valueList,0,-2)."),(");  
    }
    

    return [$catagoryList,(substr($valueList,0,-2))];
  }
  
  //CONDITIONAL STATEMENT  
    //input: Arrays of 4 strings, catagory, comparator, value, and boolean operator [[Catagory1, '=', Value1, 'AND'],[Catagory2, 'LIKE', Value2, ''], ...]
    //output: String of conditionals "Catagory1 = Value1 AND Catagory2 LIKE Value2 "
  function conditionStatement($condition){
    $catagory = varFill($condition[0]);
    $comparator = varFill($condition[1]);
    $value = varFill($condition[2]);
    $boolop = varFill($condition[3]);
    $str=" $catagory $comparator $value $boolop";
    return $str;
  }


    //takes in an array of arrays and submits each array to the conditionStatement() function compling the resulting strings and returning the result
  function conditionsPhrase($conditionsArray){
    $str='';
    foreach($conditionsArray as $condition){
      $str.=conditionStatement($condition);
    }
    return $str;
  }
  
    //input: array of arrays of update values and catagories [[catagory1, value1], [catagory2, value2], ...]
    //ouptu: string of update statements "catagory1=value1, catagory1=value2, ..."
  function changePhrase($changeArray){
    $str='';
    foreach($changeArray as $change){
      $str.=conditionStatement([$change[0],'=',$change[1],',']);  
    }
    return substr($str,0,-1); 
  }
  
   //input: array of fields [field1, field2, ...]
   //ouput: string of fields "(field1, field2, ...)"
  function fieldListPhrase($fields){
    $str='(';
    foreach($fields as $field){
      $field=varFill($field);
      $str.="$field, ";
    }  
    return (substr($str,0,-1).")");
  }
  
  
  //input Dictionary of value names and types {Value: Datatype, Value: Datatype, ...}
  //output string of values "(Value DATATYPE, Value DATATYPE, ..."
  function newValuesPhrase($values){
    $str='(';
    foreach($values as $value => $dataType){   
      $str.=conditionStatement($value,' ',$dataType,',');    
    }
    return (substr($str,0,-1).")");
  }
  
  
  
//DATA PARSERS
  
  //PARSE WRAPPERS
  //checks for additional variables needed for parsing       
  function entryTableParse($data){
    $editable=checkPost('editable','nullfunc',$_SESSION['mod']);//see if the user can edit the printed table
    $table=checkPost('eTable','varFill',"temp.miss");// which table to print
    return entryTable($data, $editable, $table);
  }
  function listParse($data){
    $wrapper=checkPost('wrapper','varFill','span');//what html element and text to place around each result
    return parseList($data,$wrapper);  
  }
  function valueParse($data){
    $rowNum=checkPost('rowNum','varFill','1'); //what row of the results to look at
    $catagory=checkPost('catagory','varFill',''); //what catagory in the row to grab
    return getValue($data, $catagory, $rowNum);
  }
  
  //TABLE FORMAT
  //outputs the resulting data into tables
  
  //generic table. headers are the row names, contents are the values
  function genTableParse($data){
    $str='<table border=1>';
    $first=TRUE;
    while($row = mysqli_fetch_array($data)){
      if($first){
        $str.='<tr>';
        foreach($row as $column => $value){
          $str.="<th>$column</th>";
        }
        $str.='</tr>';
        $first=FALSE;
      }  
      $str=$str.'<tr>'.parseRow($row,'td').'</tr>';
      
    }
    return $str;
    
  }
  
  //ENTRY TABLE, specific to db.entryView and any tables based on it
  function entryTable($data, $editable, $table){
    $str= "<h3>No Results</h3>";
    if(mysqli_num_rows($data)>0){
      $str= "<table border='1'><tr>";
      if($_SESSION["mod"]==1){
	$str.="<th>First Name</th> <th>Last Name</th>";
      }	
      $str.= "<th>Company</th>
          <th>Project</th>
          <th>Role</th>
          <th>Activity</th>
          <th>Issues</th>
          <th>Notes</th>
          <th>Time Start</th>
          <th>Time End</th>
          <th>Hours</th>";
      if($editable){$str.='<th></th>';}
      $str.="</tr>";
      $total=0;
      while($row = mysqli_fetch_array($data)) {
        $total+=$row['timeSpent'];
	$nameLines="<td class='firstName'>" . $row['firstName'] . "</td> <td class='lastName'>" . $row['lastName'] . "</td>"; 
        $id = $row['entryID'];
        $str.= "<tr id='$id$table'>";
	if($_SESSION["mod"]==1){
	  $str.=$nameLines;
	} 
	$str.= "<td class='companyName'>" . $row['companyName'] . "</td>
        <td class='projectName'>" . $row['projectName'] . "</td>
        <td class='roleName'>" . $row['roleName'] . "</td>
        <td class='activity'>" . $row['activity'] . "</td>
        <td class='issue'>" . $row['issue'] . "</td>
        <td><pre class='notes'>" . $row['notes'] . "</pre></td>
        <td class='timeStart'>
	  <time datetime='".$row['timeStart']."'>
		" . date('m/d/y g:i A', strtotime($row['timeStart'])) . "
	  </time>
	</td>
        <td class='timeStop'>
	  <time datetime='".$row['timeStop']."'>
		" . date('m/d/y g:i A', strtotime($row['timeStop'])) . "
	  </time>
	</td>
        <td class='timeHours'>" . $row['timeSpent'] . "</td>";
        $uName=$row['employeeID'];
        if($editable){
          $str.= "<td><button id='$id.edit' onClick='editRow(\"$id\", \"$uName\",\"$table\")'>Edit</button></td>";
        }
        $str.= "</tr>";
      }
      $str.= "</table><h4>$total Hours Total</h4>";
    }
    return $str;
  }
  function userInfoParse($data){
    $str='';
    if(mysqli_num_rows($data)>0){
      while($row = mysqli_fetch_array($data)) {
        $str= "
          First Name: <input name='fName' value='".$row['firstName']."'>
           Last Name: <input name='lName' value='".$row['lastName']."'><br>
          User Name: <input name='uname' required value='".$row['employeeID']."'><br> 
          Password: <input type='password' name='pass1'><br>
          Password Confirm: <input type='password' name='pass2'><br> 
          <p style='display:none;' id='passFix'>The Password Fields Must Match</p>                                                                     
          <br>
          <input type='checkbox' name='modbox' val='True'";
        if($row['Select_priv'] == 'Y'){
          $str.= " checked";
        }
        
        $str.= ">Moderator Clearance<br>";
      }
    }
    else{
      $str='No Data Found';
    }
    return $str;
  }
  //dont parse just return
  function customeParse($data){
    return $data;
  }
  
  //Deletion notification
  function delNotifParse($data){
    deletionParse($data);
  }
  
  //new user notification
  function creNotifParse($data){
    echo "New User ".$data;
  }
  
  
  //generic row to htlm wrapped content parser
  //takes in a data row
  //outputs a lines of html formatted items for the line
  function parseRow($row, $wrapper){
    $str='';
    foreach($row as $column => $value){
      if(!is_int($column)){
        if(isset($wrapper)){
         $str.="<$wrapper class='$column' value='$value'> $value </$wrapper>";
        }
      }  
    }
    return $str;
  }
  
  
  //HMTL generic
  //outputs the entire table as a series of html elements with their internals being the values.
  //parse database response to html wrapped content (no variations)
  function parseList($data, $wrapper){
    $str='';
    while($row = mysqli_fetch_array($data)){
      $str.=parseRow($row,$wrapper);  
    }
    return $str;
  }
  
  //List Generic
  //outputs the table results as a list (1,2,3,4,5), Values only
  function blandParse($data){
    $str='';
    while($row = mysqli_fetch_array($data)){
      foreach($row as $column => $value){
        if(!is_int($column)){
          $str.="$value,";
        }
      }
    }
    
    return(substr($str,0,-1));
  }
  
  
  //Nth Row
  //returns the designated row
  function getRow($data, $rowNum){
    $row=mysqli_fetch_array($data);
    for($i=1; $i<$rowNum;$i++){
      $row=mysqli_fetch_array($data);  
    }
    return $row;  
  }
  
  //Nth Value
  //Returns the designated data value from the designated row
  function getValue($data, $catagory, $rowNum){
    $row=getRow($data,$rowNum);
    return $row["$catagory"];
  }
  
  
  function deletionParse($data){
    $array=[];
    while($row= mysqli_fetch_array($data)){
      $array[]=$row['User'];
    }
    for($i=0; $i<sizeOf($array); $i++){
      $delUser=$array[$i];
      database("Drop User $delUser@localhost");
    }
  }
  
  //GENERAL FUNCTIONS
  
    //SANITIZATION
  function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
  }
  function varFill($data){
    if(isset($data)&&(!($data==''))){return test_input($data);}
    else {return null;}
  }
  
  //QUOTE FORMATTING 
  function quote($data,$reserve){
    if($data==null){
      return $reserve;
    }
    else{
     return "'".$data."'";
    }
  }
  
  //VIEW CREATION
  function testView($table, $view){
    if(strpos($table,'temp.')!==false){
      database("CREATE OR REPLACE VIEW $view AS select firstName, lastName, employeeID, entryID, companyName, projectName, roleName, activity, issue, notes, timeStart, timeStop, TIMESTAMPDIFF(SECOND, timeStart, timeStop)/3600 AS timeSpent FROM $table NATURAL JOIN db.employee");
    }
  }
  
  //IDENTITY FUNCTION
  function nullfunc($var){return $var;}
?>

<!DOCTYPE html>
<html>
<head>
  <!-- basic setup, session connect, date, user, errorchecking.-->
  <?php session_start(); 
    date_default_timezone_set('America/Chicago');
    error_reporting(E_ALL ^ E_NOTICE);
    $today=(new DateTime())->format('Y-m-d\TH:i');
    $user=$_SESSION['User'];
    $_SESSION['landing']='entry';
  ?>
</head>
<body>
  
  
  <form id="entryForm" method="post" target="iframe_b"><!-- form for new timetracker entries -->
    <?php if($_SESSION['mod']){echo "User Name:";} ?>
    <input <?php if(!$_SESSION['mod']){echo "type = 'hidden'";} ?> name='uname' value='<?php echo $user?>'><br> 
    Date Start*: <input type='datetime-local' name='sdate' value='<?php echo $today; ?>' required><br>
    Date End*: <input type='datetime-local' name='edate' value='<?php echo $today; ?>' required><br>
    <span id="timeAlert" style="display:none;">Date Start and End must be within this week.</span>
    Company*: 
    <select name='comp' id='entryComp' required> 
    </select>
    Project*: 
    <select name='proj' id='entryProj' required>
    </select>
    <br>
    Role: 
    <select name='role' id='entryRole'>
    </select>
    Activity: 
    <select name='act' id='entryAct'>
    </select>
    <br>
    Notes: <br><textarea name='notes' maxlenght='256' rows="4" cols="50"></textarea><br>
    Issues: <br><input name='bug'><br>
    <input type='submit' value='Submit'>
    <span class='notif'>*this field is required</span>
  </form>

  <div id="tempDBResults"><!-- Database results will be put here when searched --></div>

  <button type="button" id='tempRefresh'>Refresh</button><!-- Calls a database refresh on above table-->
</body>

<!DOCTYPE html>
<html>
<head>
  <?php
    session_start();
    $_SESSION['landing']='cPass'; 
  ?>
</head>
<body>
  <!-- form to create new user -->
  <form id="profileForm" method="post">
    Current Password:<input type='password' name='profilePassword' required><br>
    New Password: <input type='password' name='pass1' class='pass'><br>
    Confirm New Password: <input type='password' name='pass2' class='pass'><br> 
    <button type='button' id='showpass'> Display Password.</button>
    <p style='display:none;' id='passFix'>The Password Fields Must Match</p>
    <p style='display:none;' id='passStrength'>Passwords must contain atleast 1 special character.</p>
    <p style='display:none;' id='passLength'>Passwords must be at least 6 characters long. </p>
    <p style='display:none;' id='passCase'>Passwords must conatain at least 1 capital and 1 lowercase letter.</p>
    <br><input type='submit' value='Submit'>
  </form>
</body>

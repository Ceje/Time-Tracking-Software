<!DOCTYPE html>
<html>
  <head>
<link rel="stylesheet" href="main.css">
    <!-- load js here-->
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="timetracker.js"></script>
    <?php session_start();
      #if user is not logged in return to login page 
      if(!isset($_SESSION["User"])){
        header('Location: login.html'); 
        die();
      }
    
    ?>
  </head>
<body>
  <div id="header"><!-- Header content fills here--> </div><hr>
  <div id="content"><!-- Main content (search, entry, user edit, ...) fills here --></div><hr>
  <div id="footer"></div>
</body>

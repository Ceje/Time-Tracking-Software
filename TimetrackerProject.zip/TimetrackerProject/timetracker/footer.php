<!DOCTYPE html>
<html>
<head>
  <?php session_start(); ?>
</head>
<body>

<div id="editDiv" style="display:none;">  <!-- form for entry item edit, placed in footer so it's on available to all pages -->
  <form id="editForm" method="post">
    <?php if($_SESSION['mod']){echo "User Name:";} ?>
    <input <?php if(!$_SESSION['mod']){echo "type = 'hidden'";} ?> id='editUser' name='uname' value='<?php echo $_SESSION['User']?>'><br> 
    <input type='hidden' id='editID' name='rowID'>
    <input type='hidden' id='editTable' name='table'>
    Date Start*: <input type='datetime-local' name='sdate' id='editSDate' required><br>
    Date End*: <input type='datetime-local' name='edate' id='editEDate' required><br>
    <span id="timeAlert" style="display:none;">Date Start and End must be within this week.</span>
    Company*: 
    <select id='editComp' name='comp' required> 
    </select>
    Project*: 
    <select id='editProj' name='proj' required>
    </select>
    <br>
    Role: 
    <select id='editRole' name='role'>
    </select>
    Activity: 
    <select id='editAct' name='act'>
    </select>
    <br>
    Notes: <br><textarea id='editNotes' name='notes' maxlenght='256' rows="4" cols="50"></textarea><br>
    Issues: <input id='editBug' name='bug'><br>
    <input type='submit' value='Submit'>
    <button type='button' id='editCan'>Cancel</button>
    <button type='button' id='editDel'>Delete</button>
    <span class='notif'>*this field is required<span>
  </form>
</div>
</body>

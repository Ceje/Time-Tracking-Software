<?php
  #destroy the session when the user is done, return to login
  session_start();
  session_unset();
  session_destroy();
  header('Location: login.html');
  die();
?>
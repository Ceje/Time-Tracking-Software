INSERT INTO Company VALUES ('Company 1', 'Project A'),
                            ('Company 2', 'Project B');
                           
INSERT INTO Project VALUES ('Project A', 'Task 1'),
                            ('Project B', 'Task 1');
                         
INSERT INTO Roles VALUES ('Task 1', 'Role 1'),
                          ('Task 2', 'Role 2');
